package cmsc420.pmquadtree;

import cmsc420.pmquadtree.PMQuadtree.Black;

public interface Validator {

	public boolean valid(Black node);
}
